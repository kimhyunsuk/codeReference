/*
 * DBManager.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.db;

import java.sql.SQLException;
import java.util.Collection;

/**
 * DBManagerIfc Interface. This is the gateway to DB Operations e.g. creating a
 * table and inserting rows. Must implement this interface for every RDBMS.
 */
public interface DBManagerIfc {
    String INVALID_COL = "_QL_INVALID_COLUMN";

    /**
     * Creates a table in the Database.
     * 
     * @param tableName
     * @param columns (Must have Name and Type).
     * @return
     * @throws SQLException
     */
    public Table createTable(String tableName, Collection<Column> columns)
            throws SQLException;

    /**
     * Creates a table in the Database.
     * 
     * @param table (Must have Table Name and Columns (Name and Type)).
     * @return
     * @throws SQLException
     */
    public Table createTable(Table table) throws SQLException;

    /**
     * Insert table data. Requires
     * 
     * <pre>
     * TableData.Table.Name
     * TableData.Table.Columns(Name) 
     * TableData.DataMap(Column Name, Value)
     * </pre>
     * 
     * @param tableData
     * @return
     * @throws SQLException
     */
    void insertTableData(TableData tableData) throws SQLException;

    /**
     * Creates a Table Name based on Strings (usually File and Worksheet Names)
     * which are passed as arguments.
     * 
     * @param fileName
     * @param workSheetName
     */
    public String makeTableName(String fileName, String workSheetName);

    /**
     * Creates a Column Name based on a String (usually the field name from the
     * data file) which is passed as argument.
     * 
     * @param colName
     */
    public String makeColumnName(String colName);
}
