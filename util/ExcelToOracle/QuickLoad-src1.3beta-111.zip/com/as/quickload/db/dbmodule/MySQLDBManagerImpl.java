/*
 * OracleDBManagerImpl.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.db.dbmodule;

import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Map;

import com.as.quickload.db.Column;
import com.as.quickload.db.DBManager;
import com.as.quickload.db.Table;
import com.as.quickload.db.TableData;

/**
 * This works for MySQL and MS-Access.
 * 
 * @author Abhinav
 */
public class MySQLDBManagerImpl extends DBManager {

    /**
     * Creates a new instance on MySQLDBManagerImpl
     * 
     * @throws MalformedURLException
     */
    public MySQLDBManagerImpl() {

    }

    public Table createTable(String tableName, Collection<Column> columns)
            throws SQLException {

        String sql = " CREATE TABLE " + tableName + " (";
        String cols = "";
        for (Column it : columns) {
            if (it.getName().equals(DBManager.INVALID_COL)) {
                continue;
            }
            String tempName = "";
            String tempType = "";
            int tempSize = getColSize();

            if (!cols.equals("")) {
                cols += ",";
            }

            tempName = it.getName();

            if (it.getType() == Column.STRING) {
                tempType = "VARCHAR";
                tempSize = it.getSize() != 0 ? it.getSize() : getColSize();
                cols += tempName + " " + tempType + " (" + tempSize + ")";
            } else if (it.getType() == Column.DATE) {
                tempType = "DATE";
                cols += tempName + " " + tempType;
            }
        }
        sql += cols + ")";

        getDbHlpr().executeCreate(sql);

        return new Table(tableName, columns);
    }

    public void insertTableData(TableData tableData) throws SQLException {
        String tableName = tableData.getTable().getName();
        Collection<Column> colsa = tableData.getTable().getColumns();
        Collection<Map<String, Object>> data = tableData.getDataMap();
        String insertIntoTable = "INSERT INTO " + tableName;
        String cols = "";
        String qm = "";

        if (tableData.size() < 1) {
            return;
        }

        for (Column it : colsa) {
            String tempName = "";
            if (it.getName().equals(DBManager.INVALID_COL)) {
                continue;
            }
            if (!"".equals(cols)) {
                cols += ",";
                qm += ",";
            }

            tempName = it.getName();
            cols += tempName;
            qm += "?";
        }
        String insertIntoColumns = " (" + cols + ") VALUES (" + qm + ")";
        String sql = insertIntoTable + insertIntoColumns;
        // conf.getLog().printDebug(" Execute : " + sql);

        Connection con = null;
        PreparedStatement stmt = null;
        try {
            con = getDbHlpr().getConnection();
            con.setAutoCommit(false);
            stmt = con.prepareStatement(sql);
            for (Map<String, Object> it : data) {
                int index = 1;
                for (Column it2 : colsa) {
                    if (!it2.getName().equals(DBManager.INVALID_COL)) {
                        stmt.setObject(index++, it.get(it2.getName()), it2
                                .getType());
                    }
                }
                stmt.addBatch();
            }
            stmt.executeBatch();
            con.commit();
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
    }

    public Table createTable(Table table) throws SQLException {
        Table tbl = null;
        tbl = createTable(table.getName(), table.getColumns());
        return tbl;
    }
}
