/*
 * OracleDBManagerImpl.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.db.dbmodule;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Map;

import com.as.quickload.db.Column;
import com.as.quickload.db.DBManager;
import com.as.quickload.db.Table;
import com.as.quickload.db.TableData;

/**
 * Oracle DBManager
 */
public class OracleDBManagerImpl extends DBManager {

    /**
     * Creates a new instance of OracleDBManagerImpl
     * 
     * @throws MalformedURLException
     */
    public OracleDBManagerImpl() {

    }

    /**
     * Create a new table.
     * 
     * @see com.as.quickload.db.DBManager#createTable(java.lang.String,
     *      java.util.Collection)
     */
    public Table createTable(String tableName, Collection<Column> columns)
            throws SQLException {

        String sql = buildCreateTableSQL(tableName, columns);

        getDbHlpr().executeCreate(sql);

        return new Table(tableName, columns);
    }

    private String buildCreateTableSQL(String tableName,
            Collection<Column> columns) {
        String sql = " CREATE TABLE " + tableName + " (";
        String cols = "";
        for (Column it : columns) {
            if (it.getName().equals(DBManager.INVALID_COL)) {
                continue;
            }
            String tempName = "";
            String tempType = "";
            int tempSize = getColSize();

            if (!cols.equals("")) {
                cols += ",";
            }

            tempName = it.getName();

            if (it.getType() == Column.STRING) {
                tempType = "VARCHAR2";
                tempSize = it.getSize() != 0 ? it.getSize() : getColSize();
                cols += tempName + " " + tempType + " (" + tempSize + ")";
            } else if (it.getType() == Column.DATE) {
                tempType = "DATE";
                cols += tempName + " " + tempType;
            }
        }
        sql += cols + ")";
        return sql;
    }

    public void insertTableData(TableData tableData) throws SQLException {
        String tableName = tableData.getTable().getName();
        Collection<Column> colsa = tableData.getTable().getColumns();
        Collection<Map<String, Object>> data = tableData.getDataMap();

        if (tableData.size() < 1) {
            return;
        }

        String sql = buildInsertRowSQL(tableName, colsa);

        Connection con = null;
        PreparedStatement stmt = null;
        try {
            con = getDbHlpr().getConnection();
            con.setAutoCommit(false);
            stmt = con.prepareStatement(sql);
            for (Map<String, Object> it : data) {
                int index = 1;
                for (Column it2 : colsa) {
                    if (!it2.getName().equals(DBManager.INVALID_COL)) {
                        stmt.setObject(index++, it.get(it2.getName()), it2
                                .getType());
                    }
                }
                stmt.addBatch();
            }
            stmt.executeBatch();
            con.commit();
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
    }

    private String buildInsertRowSQL(String tableName, Collection<Column> colsa) {
        String insertIntoTable = "INSERT INTO " + tableName;
        String cols = "";
        String qm = "";

        for (Column it : colsa) {
            String tempName = "";
            if (it.getName().equals(DBManager.INVALID_COL)) {
                continue;
            }
            if (!"".equals(cols)) {
                cols += ",";
                qm += ",";
            }

            tempName = it.getName();
            cols += tempName;
            qm += "?";
        }
        String insertIntoColumns = " (" + cols + ") VALUES (" + qm + ")";
        String sql = insertIntoTable + insertIntoColumns;
        return sql;
    }

    public Table createTable(Table table) throws SQLException {
        return createTable(table.getName(), table.getColumns());
    }

}
