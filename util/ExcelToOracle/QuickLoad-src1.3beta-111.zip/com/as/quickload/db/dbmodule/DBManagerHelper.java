/* DBManagerHelper.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */
package com.as.quickload.db.dbmodule;

import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.as.quickload.Configuration;
import com.as.quickload.LogHelper;

/**
 * Helper Class. To connect to the database using the configuration and execute
 * generic queries.
 */
public class DBManagerHelper {

    private Configuration conf;

    private String conURL;

    private String user;

    private String pwd;

    public DBManagerHelper() {
        useConfiguration(Configuration.getInstance());
    }

    private void useConfiguration(Configuration aConf) {
        conf = aConf;
        try {
            init();
        } catch (Exception e) {
            throw new RuntimeException(e.toString());
        }
    }

    private void init() throws ClassNotFoundException, MalformedURLException {
        Class.forName(conf.read(Configuration.JDBC_DRIVER_CLASS));
        conURL = conf.read(Configuration.CONNECTION_URL);
        user = conf.read(Configuration.DB_USER);
        pwd = conf.read(Configuration.DB_PASSWORD);
    }

    /**
     * Returns a Database Connection, as specified by Configuration. Calls
     * <code>DriverManager.getConnection(URL, user, password);</code>
     * 
     * @return Connection
     * @throws SQLException
     */
    public Connection getConnection() throws SQLException {
        Connection con = null;
        con = DriverManager.getConnection(conURL, user, pwd);
        return con;
    }

    /**
     * Generic method to execute a SQL. Calls
     * <code>statement.executeUpdate</code>
     * 
     * @param sql
     * @throws SQLException
     */
    public void executeCreate(String sql) throws SQLException {
        LogHelper.getInstance().printDebug(" Execute : " + sql);
        Connection con = null;
        PreparedStatement stmt = null;
        try {
            con = getConnection();
            con.setAutoCommit(false);
            stmt = con.prepareStatement(sql);
            stmt.executeUpdate();
            con.commit();
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
    }
}
