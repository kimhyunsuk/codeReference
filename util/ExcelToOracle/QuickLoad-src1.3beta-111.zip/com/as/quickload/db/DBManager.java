/*
 * DBManager.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.db;

import java.sql.SQLException;
import java.util.Collection;

import com.as.quickload.Configuration;
import com.as.quickload.db.dbmodule.DBManagerHelper;

/**
 * DBManager Abstract Class. This is the gateway to DB Operations e.g. creating a
 * table and inserting rows. Must extend this for every RDBMS.
 */
public abstract class DBManager {
    public static String INVALID_COL = "_QL_INVALID_COLUMN";

    private int colSize;

    public int getColSize() {
        return colSize;
    }

    public void setColSize(int colSize) {
        this.colSize = colSize;
    }

    private DBManagerHelper dbHlpr;

    /**
     * Injects DBManagerHelper.
     * @throws MalformedURLException
     */
    public DBManager() {
        dbHlpr = new DBManagerHelper();
        Configuration conf = Configuration.getInstance();
        colSize = Integer.parseInt(conf.read(Configuration.COLUMN_SIZE));
    }

    /**
     * Creates a table in the Database.
     * 
     * @param tableName
     * @param columns (Must have Name and Type).
     * @return
     * @throws SQLException
     */
    public abstract Table createTable(String tableName,
            Collection<Column> columns) throws SQLException;

    /**
     * Creates a table in the Database.
     * 
     * @param table (Must have Table Name and Columns (Name and Type)).
     * @return
     * @throws SQLException
     */
    public abstract Table createTable(Table table) throws SQLException;

    /**
     * Insert table data. Requires
     * 
     * <pre>
     * TableData.Table.Name
     * TableData.Table.Columns(Name) 
     * TableData.DataMap(Column Name, Value)
     * </pre>
     * 
     * @param tableData
     * @return
     * @throws SQLException
     */
    public abstract void insertTableData(TableData tableData)
            throws SQLException;

    /**
     * Creates a Table Name based on Strings (usually File and Worksheet Names)
     * which are passed as arguments.
     * 
     * @param fileName
     * @param workSheetName
     */
    public String makeTableName(String fileName, String workSheetName) {
        Configuration conf = Configuration.getInstance();
        String input = (workSheetName + fileName).trim().toUpperCase();
        int maxlength = Integer.parseInt(conf
                .read(Configuration.TABLE_NAME_MAXLENGTH));
        String prefix = conf.read(Configuration.TAB_NAME_PREFIX);
        return buildName(input, maxlength, prefix);
    }

    /**
     * Creates a Column Name based on a String (usually the field name from the
     * data file) which is passed as argument.
     * 
     * @param colName
     */
    public String makeColumnName(String colName) {
        Configuration conf = Configuration.getInstance();
        String input = (colName).trim().toUpperCase();
        int maxlength = Integer.parseInt(conf
                .read(Configuration.COL_NAME_MAXLENGTH));
        String prefix = conf.read(Configuration.COL_NAME_PREFIX);
        return buildName(input, maxlength, prefix);
    }

    private String buildName(String input, int maxlength, String prefix) {
        String tmp1 = input.replaceAll("\\W", "_").replaceAll("__", "_");
        String tmp2 = prefix + tmp1;
        String tmp3 = "";
        if (tmp2.length() > maxlength) {
            tmp3 = tmp2.substring(0, maxlength);
        } else {
            tmp3 = tmp2;
        }
        return tmp3;
    }

    public DBManagerHelper getDbHlpr() {
        return dbHlpr;
    }

    public void setDbHlpr(DBManagerHelper dbHlpr) {
        this.dbHlpr = dbHlpr;
    }

}
