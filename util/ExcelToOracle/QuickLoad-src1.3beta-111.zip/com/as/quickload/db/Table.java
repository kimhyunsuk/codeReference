/*
 * Table.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.db;

import java.util.Collection;

/**
 * Table with Name, Columns and Data.
 */
public class Table {

    private String name;

    private Collection<Column> columns;

    private TableData tableData;

    public Table() {
    }

    public Table(String tableName, Collection<Column> columns) {
        this.name = tableName;
        this.columns = columns;
    }

    public TableData getData() {
        return tableData;
    }

    public void setData(TableData tableData) {
        this.tableData = tableData;
    }

    public String getName() {
        return name;
    }

    public void setName(String tableName) {
        this.name = tableName;
    }

    public Collection<Column> getColumns() {
        return columns;
    }

    public void setColumns(Collection<Column> columns) {
        this.columns = columns;
    }
}
