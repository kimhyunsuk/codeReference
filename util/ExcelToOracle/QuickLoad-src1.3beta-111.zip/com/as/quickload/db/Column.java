/*
 * Column.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.db;

/**
 * Represents one Column of the matrix formed by rows and columns.
 */
public class Column {

    private String name;

    private int type;

    private int size;

    public static final int DATE = java.sql.Types.DATE;

    public static final int STRING = java.sql.Types.VARCHAR;

    public Column() {
    }

    public Column(String name, int type) {
        this.name = name;
        this.type = type;
    }

    public Column(String name) {
        this.name = name;
        this.type = STRING;
    }

    public String getName() {
        return name;
    }

    public void setName(String columnName) {
        this.name = columnName;
    }

    public int getType() {
        return type;
    }

    public void setType(int columnType) {
        this.type = columnType;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public boolean equals(Object ob) {
        if (!(ob instanceof Column)) {
            return false;
        } else {
            Column column = (Column) ob;
            return column.getName().equalsIgnoreCase(this.getName());
        }
    }

    public String toString() {
        return getName();
    }
}
