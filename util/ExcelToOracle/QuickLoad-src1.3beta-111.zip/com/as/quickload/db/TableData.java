/*
 * TableData.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.db;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

/**
 * Table Data.
 */
public class TableData {

    private Collection<DataRow> datarows = new ArrayList<DataRow>();

    private Table table;

    public TableData() {
    }

    public Collection<DataRow> getDatarows() {
        return datarows;
    }

    public void setDatarows(Collection<DataRow> datarows) {
        this.datarows = datarows;
    }

    public void addDatarow(DataRow row) {
        datarows.add(row);
    }

    public void clear() {
        datarows = new ArrayList<DataRow>();
    }

    public Table getTable() {
        return table;
    }

    public void setTable(Table table) {
        this.table = table;
    }

    public Collection<Map<String, Object>> getDataMap() {
        Collection<Map<String, Object>> col = new ArrayList<Map<String, Object>>();
        for (DataRow dr : datarows) {
            Map<String, Object> map = new TreeMap<String, Object>();
            Collection<Cell> cells = dr.getCells();
            for (Cell cl : cells) {
                map.put(cl.getColumn().getName(), cl.getValue());
            }
            col.add(map);
        }
        return col;
    }

    public int size() {
        return datarows.size();
    }

    /**
     * Returns max 10 rows.
     * Sample Output:<pre>
     *  &lt;Value A1&gt;&lt;Value A2&gt;&lt;Value A3&gt;
     *  &lt;Value B1&gt;&lt;Value B2&gt;&lt;Value B3&gt;
     *  ...
     * </pre>
     */
    public String toString() {
        int index = 0;
        StringBuffer buf = new StringBuffer();
        for (DataRow row : datarows) {
            if (index == 10)
                break;
            buf.append(row.toString() + "\n");
            index++;
        }
        return buf.toString();
    }
}
