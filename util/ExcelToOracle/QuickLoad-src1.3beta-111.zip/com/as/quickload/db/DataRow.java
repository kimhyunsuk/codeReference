/*
 * DataRow.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.db;

import java.util.ArrayList;
import java.util.Collection;

/**
 * One row of Data.
 */
public class DataRow {

    private Collection<Cell> cells = new ArrayList<Cell>();

    public DataRow() {
    }

    public void addColumnValue(Cell cell) {
        this.getCells().add(cell);
    }

    public void setColumnValues(Collection<Cell> cells) {
        this.setCells(cells);
    }

    public void reset() {
        this.setCells(null);
    }

    public Collection<Cell> getCells() {
        return cells;
    }

    public void setCells(Collection<Cell> cells) {
        this.cells = cells;
    }
    
    public String toString() {
        StringBuffer buf = new StringBuffer();
        for (Cell cell : cells) {
            if (!cell.getColumn().getName().equals(DBManager.INVALID_COL)) {
                buf.append("<" + cell.getValue() + ">");
            }
        }
        return buf.toString();
    }
}
