/*
 * Configuration.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute
 * it and/or modify it under the terms of the
 * Apache License v2.0
 */

package com.as.quickload;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Objects of this class will encapsulate the Configuration information needed
 * for the purpose. Implemented as a Singleton.
 */
public class Configuration {

    public static final String JDBC_DRIVER_CLASS = "JDBC_DRIVER_CLASS";

    public static final String DB_MANAGER = "DB_MANAGER";

    public static final String CONNECTION_URL = "CONNECTION_URL";

    public static final String DB_USER = "DB_USER";

    public static final String DB_PASSWORD = "DB_PASSWORD";

    public static final String COLUMN_SIZE = "COLUMN_SIZE";

    public static final String TAB_NAME_PREFIX = "TAB_NAME_PREFIX";

    public static final String COL_NAME_PREFIX = "COL_NAME_PREFIX";

    public static final String BATCH_SIZE = "BATCH_SIZE";

    public static final String DATE_FORMAT = "DATE_FORMAT";

    public static final String FILE_READER = "FILE_READER";

    public static final String READ_NUM_AS_TEXT = "READ_NUM_AS_TEXT";

    public static final String LOG_FILE = "LOG_FILE";

    public static final String TRIM = "TRIM";

    public static final String CASE = "CASE";

    public static final String TABLE_NAME_MAXLENGTH = "TABLE_NAME_MAXLENGTH";

    public static final String COL_NAME_MAXLENGTH = "COL_NAME_MAXLENGTH";
    
    public static final String SKIP_HIDDEN_COLS = "SKIP_HIDDEN_COLS";

    private Properties cache;

    private static Configuration instance;

    private Configuration() {

    }

    /**
     * Create a new instance of the Configuration Object if it doesn't already
     * exist. Otherwise the existing instance is returned irrespective of the
     * fileName specified.
     * 
     * @param configFile
     * @return Configuration
     * @throws IOException I/O Exception
     */
    public synchronized static Configuration loadFromFile(String configFile)
            throws IOException {
        if (instance == null) {
            instance = new Configuration();
            FileInputStream is = new FileInputStream(configFile);
            Properties lCache = new Properties();
            lCache.load(is);
            instance.setProperties(lCache);
        }

        return instance;
    }

    /**
     * @return existing instance of the Configuration
     */
    public static Configuration getInstance() {
        return instance;
    }

    /**
     * Read a value from the Configuration object. Fields of this class are used
     * as Keys.
     * 
     * @param key
     * @return String
     */
    public String read(String key) {
        if (key.equals(COLUMN_SIZE)) {
            return isKeyEmpty(key) ? "80" : (String) cache.get(key);
        } else if (key.equals(TAB_NAME_PREFIX)) {
            return isKeyEmpty(key) ? "T_" : (String) cache.get(key);
        } else if (key.equals(COL_NAME_PREFIX)) {
            return isKeyEmpty(key) ? "C_" : (String) cache.get(key);
        } else if (key.equals(COLUMN_SIZE)) {
            return isKeyEmpty(key) ? "80" : (String) cache.get(key);
        } else if (key.equals(BATCH_SIZE)) {
            return isKeyEmpty(key) ? "50" : (String) cache.get(key);
        } else if (key.equals(DATE_FORMAT)) {
            return isKeyEmpty(key) ? "MM/dd/yyyy HH:mm:ss" : (String) cache
                    .get(key);
        } else if (key.equals(READ_NUM_AS_TEXT)) {
            return isKeyEmpty(key) ? "Yes" : (String) cache.get(key);
        } else if (key.equals(CASE)) {
            return isKeyEmpty(key) ? "Keep" : (String) cache.get(key);
        } else if (key.equals(TRIM)) {
            return isKeyEmpty(key) ? "Yes" : (String) cache.get(key);
        } else if (key.equals(TABLE_NAME_MAXLENGTH)) {
            return isKeyEmpty(key) ? "25" : (String) cache.get(key);
        } else if (key.equals(COL_NAME_MAXLENGTH)) {
            return isKeyEmpty(key) ? "25" : (String) cache.get(key);
        } else if (key.equals(SKIP_HIDDEN_COLS)) {
            return isKeyEmpty(key) ? "No" : (String) cache.get(key);
        }else
            return isKeyEmpty(key) ? "" : (String) cache.get(key);
    }

    /**
     * Set a value in the Configuration. Can be used to override a property.
     * 
     * @param key
     * @param value
     */
    public void set(String key, String value) {
        cache.setProperty(key, value);
    }

    /**
     * Set the Properties object.
     * 
     * @param cache
     */
    private void setProperties(Properties cache) {
        this.cache = cache;
    }

    public boolean isValid() {
        if (isNULL(DB_MANAGER) || isNULL(FILE_READER) || isNULL(CONNECTION_URL)
                || isNULL(DB_USER) || isNULL(DB_PASSWORD)
                || isNULL(JDBC_DRIVER_CLASS)) {
            return false;
        }
        if (!read(CASE).equalsIgnoreCase("Upper")
                && !read(CASE).equalsIgnoreCase("Lower")
                && !read(CASE).equalsIgnoreCase("Keep")) {
            return false;
        }

        if (!read(TRIM).equalsIgnoreCase("Yes")
                && !read(TRIM).equalsIgnoreCase("No")) {
            return false;
        }
        
        if (!read(SKIP_HIDDEN_COLS).equalsIgnoreCase("Yes")
                && !read(SKIP_HIDDEN_COLS).equalsIgnoreCase("No")) {
            return false;
        }
        
        if (!read(READ_NUM_AS_TEXT).equalsIgnoreCase("Yes")
                && !read(READ_NUM_AS_TEXT).equalsIgnoreCase("No")) {
            return false;
        }

        if (!isNumber(COLUMN_SIZE) || !isNumber(BATCH_SIZE)
                || !isNumber(COL_NAME_MAXLENGTH)
                || !isNumber(TABLE_NAME_MAXLENGTH)) {
            return false;
        }

        return true;
    }

    /**
     * Check considering the default values
     * 
     * @param key
     * @return
     */
    private boolean isNULL(String key) {
        return "".equals(read(key).trim()) || read(key) == null;
    }

    /**
     * Check considering the as-is values
     * 
     * @param key
     * @return
     */
    private boolean isKeyEmpty(String key) {
        return cache.get(key) == null
                || "".equals(((String) cache.get(key)).trim());
    }

    private boolean isNumber(String key) {
        try {
            Integer.parseInt(read(key));
        } catch (NumberFormatException ne) {
            return false;
        }
        return true;
    }
}
