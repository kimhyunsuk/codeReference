/*
 * Factory.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload;

import com.as.quickload.db.DBManager;
import com.as.quickload.file.FileReaderIfc;

/**
 * Factory for obtaining instances of FileManagers and DBManagers.
 */
public class Factory {

    /** Creates a new instance of FileManagerFactory */
    private Factory() {
    }

    /**
     * Create a new instance of the Class className
     * 
     * @param className
     * @return FileReaderIfc instance
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public static FileReaderIfc createFileReader(String className)
            throws ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        FileReaderIfc fm = (FileReaderIfc) Class.forName(className)
                .newInstance();
        return fm;
    }

    /**
     * Create a new instance of the Class className
     * 
     * @param className
     * @return DBManager instance
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     */
    public static DBManager createDBManager(String className)
            throws ClassNotFoundException, InstantiationException,
            IllegalAccessException {
        DBManager dm = (DBManager) Class.forName(className).newInstance();
        return dm;
    }
}
