/*
 * FileReaderIfc.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.file;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Collection;
import java.util.Vector;

/**
 * FileReaderIfc Interface. This is the gateway to File Operations e.g. reading
 * a file. Must implement this interface for every File Type e.g. Excel, Text...
 */
public interface FileReaderIfc {

    String INDETERMINATE = "_INDETERMINATE";
    String HIDDEN = "_HIDDENCOL";

    /**
     * Returns one row (record) from the File from the current cursor.
     * If a column is hidden, return the Cell Value as FileReaderIfc.HIDDEN. If a cell
     * can't be evaluated, return as FileReaderIfc.INDETERMINATE.
     * @return
     */
    Vector<String> getRow();

    /**
     * Returns list of worksheets. If the File format doesn't have worksheets,
     * the implementation should return a collection having 1 arbitrary string
     * element.
     * 
     * @return
     */
    Collection<String> getWorksheets();

    /**
     * Loads worksheet. This may only be applicable for Excel files. Other
     * implementations whose format doesn't have the concept of worksheets can
     * just load the file ignoring the index.
     * 
     * @param index Index of Worksheet (0 Based)
     * @return
     */
    void loadWorksheet(int index) throws FileNotFoundException, IOException;

    /**
     * Moves cursor to the next row. Return false if there are no more rows.
     * 
     * @return true/false
     */
    boolean next();

    /**
     * Load the file.
     * 
     * @return true/false
     */
    boolean loadFile(final String fileName) throws IOException,
            FileNotFoundException;
}
