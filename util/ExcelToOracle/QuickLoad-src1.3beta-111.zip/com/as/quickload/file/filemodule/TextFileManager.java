/*
 * TextFileManager.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload.file.filemodule;

/**
 * 
 */
public class TextFileManager {

    /** Creates a new instance of TextFileManager */
    public TextFileManager() {
    }

}
