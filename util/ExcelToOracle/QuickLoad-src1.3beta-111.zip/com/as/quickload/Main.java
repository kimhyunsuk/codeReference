/*
 * Main.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload;

import java.io.IOException;
import java.lang.reflect.Array;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

/**
 * Command Line entry to QuickLoad
 * 
 * @author Abhinav
 */
public class Main {

    private static final String CONFIG_ARG = "config";

    private static final String DATA_ARG = "data";

    private static final String LOG_ARG = "log";

    /**
     * Creates a new instance of Main
     */
    public Main() {
    }

    /**
     * Arguments : <code>-config "configuration file" -data "data file" -log "log file" </code>
     * Requires JDBC Driver, POI and CLI on the classpath.
     * 
     * @param
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws ParseException
     */
    @SuppressWarnings("static-access")
    public static void main(String[] args) throws ClassNotFoundException,
            InstantiationException, IllegalAccessException, ParseException {

        System.out.println();

        Options options = null;
        Configuration conf = null;

        try {
            Option logFile = OptionBuilder.withArgName("log").hasArg()
                    .withDescription("use given file for log").create(LOG_ARG);
            logFile.setRequired(false);

            Option dataFile = OptionBuilder.withArgName("data").hasArg()
                    .withDescription("data file").create(DATA_ARG);
            dataFile.setRequired(true);

            Option configFile = OptionBuilder.withArgName("config").hasArg()
                    .withDescription("configuration file").create(CONFIG_ARG);
            configFile.setRequired(true);

            options = new Options();
            options.addOption(configFile);
            options.addOption(logFile);
            options.addOption(dataFile);

            CommandLineParser parser = new GnuParser();
            CommandLine line = null;
            line = parser.parse(options, args);

            LoadExecutor proc = new LoadExecutor();
            // Initialize configuration
            System.out.print(" Initializing the Configuration ... ");
            conf = Configuration.loadFromFile(line.getOptionValue(CONFIG_ARG));
            System.out.println(" Done.");

            if (line.getOptionValue(LOG_ARG) != null) {
                conf.set(Configuration.LOG_FILE, line.getOptionValue(LOG_ARG));
            }

            System.out.print(" Initializing the Logger ... ");
            LogHelper.getLogHelper(conf.read(Configuration.LOG_FILE));
            System.out.println(" Done.");

            if ((line.hasOption(CONFIG_ARG) && line.getOptionValue(CONFIG_ARG) == null)
                    || (line.hasOption(DATA_ARG) && line
                            .getOptionValue(DATA_ARG) == null)
                    || (line.hasOption(LOG_ARG) && line.getOptionValue(LOG_ARG) == null)
                    || (Array.getLength(line.getOptions()) > 3)) {
                throw new ParseException(
                        "Invalid or Missing Command Line Arguments.\n");
            }

            boolean parseFileNames = false;

            for (String elem : args) {
                if (elem.equals("-" + DATA_ARG)) {
                    parseFileNames = true;
                    continue;
                }

                if (elem.equals("-" + LOG_ARG) || elem.equals("-" + CONFIG_ARG)) {
                    parseFileNames = false;
                }

                if (parseFileNames) {
                    System.out.println(" Now Loading " + elem + " ... ");
                    ArrayList<String> tables = proc.execute(elem);
                    if (tables != null && !tables.isEmpty()) {
                        System.out.println("\t File Loaded in Table(s): "
                                + tables);
                    } else {
                        System.out.println("\t Could not be loaded. ");
                    }
                }
            }
            
        } catch (ParseException exp) {
            System.err.println("Invalid or Missing Argument.\n"
                    + exp.getMessage());
            printOptions(options);
        } catch (SQLException e) {
            System.err.println(" Database Error : " + e.getErrorCode() + ","
                    + e.getMessage());
            LogHelper.getInstance().printError(
                    " Database Error : " + e.getErrorCode() + ","
                            + e.getMessage());
        } catch (IOException e) {
            System.err.println(" Filesystem Error : " + e.getMessage());
            LogHelper.getInstance().printError(
                    " Filesystem Error : " + e.getMessage());
        } finally {
            System.out.println("Done.");
        }
    }

    private static void printOptions(Options options) {
        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp("java -cp <classpath> com.as.quickload.Main",
                options);
    }
}
