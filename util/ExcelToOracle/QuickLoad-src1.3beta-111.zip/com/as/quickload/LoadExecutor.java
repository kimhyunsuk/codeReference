/*
 * LoadExecutor.java
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;

import com.as.quickload.db.Cell;
import com.as.quickload.db.Column;
import com.as.quickload.db.DBManager;
import com.as.quickload.db.DataRow;
import com.as.quickload.db.Table;
import com.as.quickload.db.TableData;
import com.as.quickload.file.FileReaderIfc;

/**
 * Main processing entry point.
 */
public class LoadExecutor {

    private Configuration conf;

    /**
     * Start the execution of reading the file, creating tables and loading the
     * data. The Configuration must be set and valid as a prerequisite.
     * 
     * @param fileName File Name
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws FileNotFoundException
     * @throws IOException
     * @throws SQLException
     */
    public ArrayList<String> execute(String fileName)
            throws ClassNotFoundException, InstantiationException,
            IllegalAccessException, FileNotFoundException, IOException,
            SQLException {

        ArrayList<String> returnArray = new ArrayList<String>();
        Configuration aConf = Configuration.getInstance();

        if (aConf == null || !aConf.isValid()) {
            throw new RuntimeException("Invalid or null Configuration");
        }

        this.conf = aConf;

        LogHelper qlLog = LogHelper.getLogHelper(conf
                .read(Configuration.LOG_FILE));
        String fileShortName = "";
        if (fileName.lastIndexOf(java.io.File.separatorChar) != -1) {
            fileShortName = fileName.substring(fileName
                    .lastIndexOf(java.io.File.separatorChar) + 1);
        }

        FileReaderIfc fm = Factory.createFileReader(conf
                .read(Configuration.FILE_READER));
        DBManager dm = Factory.createDBManager(conf
                .read(Configuration.DB_MANAGER));
        if (!fm.loadFile(fileName)) {
            return null;
        }
        Collection<String> sheets = fm.getWorksheets();
        int sheetIndx = 0;
        for (String elem : sheets) {
            Table table = new Table();
            String tblnm = dm.makeTableName(fileShortName, elem);
            table.setName(tblnm);
            qlLog.printInfo(" Worksheet : " + elem + " Table : " + tblnm);
            fm.loadWorksheet(sheetIndx);
            boolean isFirst = true;
            ArrayList<Column> header = null;
            int headerSize = 0;
            TableData data = new TableData();
            data.setTable(table);
            while (fm.next()) {
                Vector<String> vec = fm.getRow();
                if (vec.size() > 0) {
                    if (isFirst) {
                        // header row
                        Collection<Column> columns = getColumns(vec, dm);
                        table.setColumns(columns);
                        dm.createTable(table);
                        returnArray.add(tblnm);
                        header = new ArrayList<Column>(columns);
                        headerSize = header.size();
                        qlLog.printInfo(" Columns : " + columns);
                        isFirst = false;
                    } else {
                        int i = 0;
                        DataRow row = new DataRow();
                        for (String el : vec) {
                            if (headerSize > i) {
                                Cell cell = new Cell();
                                cell.setColumn(header.get(i));
                                cell.setValue(getValue(el));
                                row.addColumnValue(cell);
                                ++i;
                            }
                        }
                        data.addDatarow(row);
                    }
                }
                if (data.size() != 0
                        && data.size() == Integer.parseInt(conf
                                .read(Configuration.BATCH_SIZE))) {
                    dm.insertTableData(data);
                    data.clear();
                }
            }
            dm.insertTableData(data);
            qlLog.printInfo(" Processing Finished: " + elem);
            ++sheetIndx;
        }
        return returnArray;
    }

    private Collection<Column> getColumns(Vector<String> vec, DBManager dm) {
        Collection<Column> c = new ArrayList<Column>();
        for (String s : vec) {
            String colName = null;
            Column col = new Column();
            if (s == null || s.equals(FileReaderIfc.INDETERMINATE)
                    || s.equals(FileReaderIfc.HIDDEN)) {
                colName = DBManager.INVALID_COL;
            } else {
                colName = dm.makeColumnName(s);
                if (c.contains(new Column(colName))) {
                    int i = 0;
                    while (c.contains(new Column(colName + (++i)))) {
                    }
                    colName += i;
                }
            }
            col.setName(colName);
            col.setType(Column.STRING);
            c.add(col);
        }
        return c;
    }

    /**
     * Utility method to apply the CASE Configuration before inserting.
     * 
     * @param object
     * @return String
     */
    public Object getValue(Object object) {
        if (object instanceof String && object != null) {
            String tmp = (String) object;
            if (conf.read(Configuration.CASE).equalsIgnoreCase("Upper")) {
                tmp = ((String) object).toUpperCase();
            } else if (conf.read(Configuration.CASE).equalsIgnoreCase("Lower")) {
                tmp = ((String) object).toLowerCase();
            }
            if (!conf.read(Configuration.TRIM).equalsIgnoreCase("No")) {
                tmp = tmp.trim();
            }
            return tmp;
        }
        return object;
    }
}
