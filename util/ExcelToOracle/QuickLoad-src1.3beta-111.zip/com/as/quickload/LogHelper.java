/* 
 * LogHelper.java
 * Created on June 24, 2006, 10:58 PM
 * Copyright (C) 2006 Abhinav Srivastava
 * This program is free software; you can redistribute 
 * it and/or modify it under the terms of the 
 * Apache License v2.0
 */

package com.as.quickload;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

/**
 * Logging Utility. Implemented as a Singleton.
 */
public class LogHelper {

    private Logger logger = null;

    public Logger getLogger() {
        return logger;
    }

    private void setLogger(Logger logger) {
        this.logger = logger;
    }

    private static LogHelper instance;

    private LogHelper() {

    }

    public static LogHelper getInstance() {
        return instance;
    }

    /**
     * Creates a new instance of the LogHelper Object if it doesn't already
     * exist. Otherwise the existing instance is returned irrespective of the
     * fileName specified. If file name is NULL, log messages are redirected to
     * the Console.
     * 
     * @param fName log file
     * @return LogHelper
     * @throws IOException I/O Exception
     */
    public synchronized static LogHelper getLogHelper(String fName)
            throws IOException {
        if (instance == null) {
            instance = new LogHelper();
            Logger logger = null;
            logger = Logger.getLogger("com.as.quickload");
            logger.setUseParentHandlers(false);
            logger.getParent().setLevel(Level.FINEST);
            instance.setLogger(logger);
            if (fName == null || fName.trim().length() == 0) {
                ConsoleHandler c1 = new ConsoleHandler();
                c1.setLevel(Level.FINEST);
                logger.addHandler(c1);
                c1.setFormatter(new Formatter() {
                    public String format(LogRecord record) {
                        return getDateStamp() + " " + record.getMessage()
                                + "\n";

                    }
                });
            } else {
                FileHandler f2 = new FileHandler(fName, true);
                f2.setFormatter(new Formatter() {
                    public String format(LogRecord record) {
                        return getDateStamp() + " " + record.getMessage()
                                + "\n";

                    }
                });
                f2.setLevel(Level.FINEST);
                logger.addHandler(f2);
            }
        }
        return instance;
    }

    public void printError(String msg) {
        logger.severe("ERROR " + msg);
    }

    public void printInfo(String msg) {
        logger.fine("INFO " + msg);
    }

    public void printDebug(String msg) {
        logger.finest("DEBUG " + msg);
    }

    private static String getDateStamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd HH:mm:ss");
        return sdf.format(new Date());
    }
}
